from setuptools import setup

setup(
    name='tippiLink',
    version='0.15',
    packages=['tippiLink'],
    install_requires=[
        "requests==2.18.4"
    ],
)